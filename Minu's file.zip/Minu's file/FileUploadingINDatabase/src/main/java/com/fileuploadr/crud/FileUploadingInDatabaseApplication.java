package com.fileuploadr.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadingInDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadingInDatabaseApplication.class, args);
	}

}
