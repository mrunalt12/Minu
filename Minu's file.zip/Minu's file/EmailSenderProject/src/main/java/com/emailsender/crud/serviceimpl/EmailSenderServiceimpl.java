package com.emailsender.crud.serviceimpl;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.emailsender.crud.model.EmailSender;
import com.emailsender.crud.service.EmailSenderService;

@Service
public class EmailSenderServiceimpl implements EmailSenderService{
	
	@Autowired
	private JavaMailSender mailsender;

	@Override
	public void sendEmail(EmailSender es) {
		SimpleMailMessage smm= new SimpleMailMessage();
		smm.setFrom(es.getFromEmail());
		smm.setTo(es.getToEmail());
		smm.setSubject(es.getSubject());
		smm.setText(es.getTextmsg());
		
		mailsender.send(smm);
		System.out.println("Email send");
		
	}

	///sending attachment
	@Override
	public void sendattachment(EmailSender es) {
		MimeMessage msg=mailsender.createMimeMessage();
		try {
			MimeMessageHelper helper=new MimeMessageHelper(msg, true);
			helper.setFrom(es.getFromEmail());
			helper.setTo(es.getToEmail());
			helper.setText(es.getTextmsg());
			helper.setSubject(es.getSubject());
			
			//choosing file
			FileSystemResource file=new FileSystemResource("E:\\other\\CV.docx");
			helper.addAttachment(file.getFilename(), file);
			mailsender.send(msg);
		}
		catch (Exception e) {
			System.out.println("attachment not sent");
		}
		
	}

}
