package com.emailsender.crud.model;

import lombok.Data;


@Data
public class EmailSender {
	private String fromEmail;
	private String toEmail;
	private String textmsg;
	private String subject;

}
