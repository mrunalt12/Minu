package com.emailsender.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.emailsender.crud.model.EmailSender;
import com.emailsender.crud.service.EmailSenderService;

@RestController
public class EmailController {
	
	@Autowired
	EmailSenderService service;
	
	@Value("${spring.mail.username}")
	private String fromEmail;
	
	@PostMapping(value = "/sendEmail")
	public String sendEmail(@RequestBody EmailSender es)
	{
		es.setFromEmail(fromEmail);
		try {
			service.sendEmail(es);
			return "Email send successfully";
		}
		catch(Exception e){
			return "Email not send";
		}
	}
	
	@PostMapping(value = "/sendattachment")
	public String sendAttachViaEmail(@RequestBody EmailSender es)
	{
		es.setFromEmail(fromEmail);
		try {
			service.sendattachment(es);
			return "Attachment send sucessfully";
		}
		catch(Exception e){
			return "Attachment not send";
		}
	}

}
