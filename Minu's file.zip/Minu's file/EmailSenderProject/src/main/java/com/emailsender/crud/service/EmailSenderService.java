package com.emailsender.crud.service;

import com.emailsender.crud.model.EmailSender;

public interface EmailSenderService {

	void sendEmail(EmailSender es);

	void sendattachment(EmailSender es);

}
