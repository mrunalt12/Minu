package com.emailsender.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailSenderProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
