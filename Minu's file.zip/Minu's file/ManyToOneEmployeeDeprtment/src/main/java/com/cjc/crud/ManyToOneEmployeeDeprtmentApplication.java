package com.cjc.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManyToOneEmployeeDeprtmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManyToOneEmployeeDeprtmentApplication.class, args);
	}

}
