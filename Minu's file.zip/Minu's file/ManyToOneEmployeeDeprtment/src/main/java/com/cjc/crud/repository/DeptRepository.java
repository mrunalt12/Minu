package com.cjc.crud.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.crud.model.Department;

@Repository
public interface DeptRepository extends JpaRepository<Department, Integer>{

	Department findAllByDname(String dnm);

	Department findByDname(String dnm);

}
