package com.cjc.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.crud.model.Department;
import com.cjc.crud.model.Employee;
import com.cjc.crud.service.HomeService;

@RestController
public class HomeController {
	
	@Autowired
	HomeService hs;
	
	// 1st**********insertEmpData***
	@RequestMapping(value = "/insertEmpData/{dname}", method = RequestMethod.POST)
	public String insertData(@RequestBody List<Employee> emp,@PathVariable("dname") String dnm)
	{
		
		List<Employee> elist=hs.saveEmployee(emp,dnm);
		
		return "Employee added Successfully ";
	}
	
	//2nd***********getEmpData*******
	@RequestMapping(value = "/getEmpData", method = RequestMethod.GET)
	public Iterable<Employee> getEmpData()
	{
		Iterable<Employee> elist=hs.getEmpData();
		
		return elist;
	}
	
	
	//3rd****************deleteEmpData************
	@RequestMapping(value = "/deleteEmpData/{eid}", method = RequestMethod.DELETE)
	public String deleteEmpData(@PathVariable("eid") int id,@RequestBody Department d)
	{
		hs.deleteEmpData(id,d);
		return "deleted successfully";
	}
	
	
	
	//4th****************updateEmpData************
	@RequestMapping(value = "/updateEmpData/{eid}", method = RequestMethod.PUT)
	public String updateEmpData(@PathVariable("eid") int id,@RequestBody Employee e)
	{
		Employee emp=hs.updateEmpData(id,e);
		
		
		return "Updated successfully";
	}
		
	
	//7th******get employee details by name***//
	@RequestMapping(value = "/getEmpbyDname/{dname}", method = RequestMethod.GET)
	public List<Employee> findEmpByDeptName(@PathVariable("dname") String dnm)
	{
		List<Employee> elist=hs.findEmpByDeptName(dnm);
		return elist;
		
	}
	
	//8th****************data save in perticular dept********************
	@RequestMapping(value = "/saveByDepartmentName/{dname}", method = RequestMethod.POST)
	public String saveBydepartment(@PathVariable("dname") String dnm,@RequestBody Employee e)
	{
		Employee em=hs.saveEmpdept(dnm,e);
		return "Sucessfull Employee save";
	}
	
}
