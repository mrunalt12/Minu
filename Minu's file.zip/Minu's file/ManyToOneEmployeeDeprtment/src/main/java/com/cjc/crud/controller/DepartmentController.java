package com.cjc.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.crud.model.Department;
import com.cjc.crud.service.HomeService;

@RestController
public class DepartmentController {
	
	@Autowired
	HomeService hs;
	
	///******department********//
		//5th****************insertDeptData************
		@RequestMapping(value = "/insertDeptData", method = RequestMethod.POST)
		public String insertDeptData(@RequestBody Department d)
		{
			Department dept=hs.insertDeptData(d);
			
			return "Department added Successfully";
		}
		
		//6th****************getDeptData************
		@RequestMapping(value = "/getDeptData", method = RequestMethod.GET)
		public List<Department> getDeptData()
		{
			List<Department> dept=hs.getDeptData();
			
			return dept;
		}

}
