package com.cjc.crud.service;

import java.util.List;

import com.cjc.crud.model.Department;
import com.cjc.crud.model.Employee;

public interface HomeService {

	public List<Employee> saveEmployee(List<Employee> emp, String dnm);

	public Iterable<Employee> getEmpData();

	public void deleteEmpData(int id, Department d);

	public Employee updateEmpData(int id, Employee e);

	//*****department*****//
	public Department insertDeptData(Department d);

	public List<Department> getDeptData();

	public List<Employee> findEmpByDeptName(String dnm);

	public Employee saveEmpdept(String dnm, Employee e);
		

}
