package com.cjc.crud.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.crud.model.Department;
import com.cjc.crud.model.Employee;
import com.cjc.crud.repository.DeptRepository;
import com.cjc.crud.repository.EmployeeRepository;
import com.cjc.crud.service.HomeService;

@Service
public class HomeServiceimpl implements HomeService{
	@Autowired
	EmployeeRepository er;
	
	@Autowired
	DeptRepository dr;

	@Override
	public List<Employee> saveEmployee(List<Employee> emp,String dnm) {
		Department dept=dr.findByDname(dnm);
		for(Employee e:emp)
		{
			e.setDpt(dept);;
		}
		List<Employee> elist=er.saveAll(emp);
		return elist;
	}

	@Override
	public Iterable<Employee> getEmpData() {
		
		return er.findAll();
	}

	@Override
	public void deleteEmpData(int id,Department d) {
		er.deleteById(id);
		dr.save(d);
		
	}

	@Override
	public Employee updateEmpData(int id,Employee e) {
		Employee emp=er.findByEid(id);
		emp.setEid(id);
		emp.setEname(e.getEname());
		emp.setSalary(e.getSalary());
		emp.setDpt(e.getDpt());
		
		return er.save(emp);
	}

	@Override
	public Department insertDeptData(Department d) {
		
		return dr.save(d);
	}

	@Override
	public List<Department> getDeptData() {
		
		return dr.findAll();
	}

	@Override
	public List<Employee> findEmpByDeptName(String dnm) {
		
		Department dpt=dr.findAllByDname(dnm);
		List<Employee> elist=er.findByDpt_did(dpt.getDid());
		return elist;
	}

	@Override
	public Employee saveEmpdept(String dnm, Employee e) {
		
		Department dpt=dr.findAllByDname(dnm);
		e.setDpt(dpt);
		Employee emp=er.save(e);
		return emp;
	}


}
