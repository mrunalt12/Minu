package com.cjc.crud.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Customer {
	
	@Id
	private int cid;
	private String name;
	private String mobile;
	
	@OneToOne(cascade = CascadeType.ALL,mappedBy = "cust")
	private Product pp;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Product getPp() {
		return pp;
	}

	public void setPp(Product pp) {
		this.pp = pp;
	}
	
	

}
