package com.cjc.crud.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.crud.model.Customer;
import com.cjc.crud.model.Product;
import com.cjc.crud.repository.CustomerReository;
import com.cjc.crud.repository.ProductRepository;
import com.cjc.crud.service.HomeService;

@Service
public class HomeServiceimpl implements HomeService{
	@Autowired
	CustomerReository cr;
	
	@Autowired
	ProductRepository pr;

	@Override
	public Customer getCustomerData(Customer c) {
		c.getPp();
		return cr.save(c);
	}

	@Override
	public Product getProductData(Product p) {
		p.getCust();
		return pr.save(p);
	}

}
