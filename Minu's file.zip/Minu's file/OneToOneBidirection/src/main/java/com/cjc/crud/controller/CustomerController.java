package com.cjc.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.crud.model.Customer;
import com.cjc.crud.model.Product;
import com.cjc.crud.service.HomeService;

@RestController
public class CustomerController {
	
	@Autowired
	HomeService hs;
	
	@PostMapping("/insertcustomerData")
	public Customer getCustomerData(@RequestBody Customer c)
	{
		Customer cu=hs.getCustomerData(c);
		return cu;
	}
	

}
