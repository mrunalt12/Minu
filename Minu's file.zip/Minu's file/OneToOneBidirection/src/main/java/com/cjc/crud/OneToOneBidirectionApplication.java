package com.cjc.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cjc.crud.repository.CustomerReository;

@SpringBootApplication
public class OneToOneBidirectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneToOneBidirectionApplication.class, args);
		
	}

}
