package com.cjc.crud.service;

import org.springframework.stereotype.Component;

import com.cjc.crud.model.Customer;
import com.cjc.crud.model.Product;

@Component
public interface HomeService {

	Customer getCustomerData(Customer c);

	Product getProductData(Product p);
	
	

}
