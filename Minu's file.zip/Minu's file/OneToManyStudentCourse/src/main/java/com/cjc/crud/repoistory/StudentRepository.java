package com.cjc.crud.repoistory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cjc.crud.model.Course;
import com.cjc.crud.model.Student;

public interface StudentRepository extends JpaRepository<Student, Integer>{

	List<Student> findBySid(int id);

	

	Student findByName(String name);

	//Student deleteBySid(int id);

}
