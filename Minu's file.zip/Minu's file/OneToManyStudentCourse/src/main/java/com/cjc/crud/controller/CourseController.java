package com.cjc.crud.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.crud.model.Course;
import com.cjc.crud.model.Student;
import com.cjc.crud.service.HomeService;

@RestController
public class CourseController {
	
	@Autowired
	HomeService hs;
	
	@RequestMapping(value="/insertcourse",method = RequestMethod.POST )
	public String insertcourse(@RequestBody Course c)
	{
		 Course cl=hs.insertcourse(c);
		return "Added Successfully";
		
	}
	
	@RequestMapping(value="/getcourse",method = RequestMethod.GET)
	public List<Course> getdata()
	{
		List<Course> cl=hs.getdata();
		return cl;
	}
	@RequestMapping(value="/updateCourse/{cid}",method = RequestMethod.PUT)
	public String updateCourse(@PathVariable("cid") int id,@RequestBody Course c)
	{
		Course cl=hs.updateCourse(id,c);
		return "updated";
	}
	@RequestMapping(value="/getSingleStu/{name}",method = RequestMethod.GET)
	public Course getSingleStu(@PathVariable("name") String nm)
	{
		Student st=hs.getbyname(nm);
		Course c=hs.getSingleStu(st);
		return c;
	}
}
