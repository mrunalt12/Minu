package com.cjc.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.crud.model.Student;
import com.cjc.crud.service.HomeService;

@RestController
public class StudentController {
	
	@Autowired
	HomeService hs;
	
	@RequestMapping(value="/insertStudent",method = RequestMethod.POST )
	public String insertStu(@RequestBody List<Student> sl)
	{
		List<Student> slist=hs.insertStu(sl);
		
		return "Student added";
	}
	
	@RequestMapping(value="/getStudent",method = RequestMethod.GET)
	public List<Student> getStu()
	{
		List<Student> sl=hs.getStu();
		return sl;
	}
	@RequestMapping(value="/deleteStudent/{sid}",method = RequestMethod.DELETE)
	public String deleteStu(@PathVariable("sid") int id)
	{
		 hs.deleteStu(id);
		return "Deleted successfully";
	}
	
	
	
	
	
	
	

}
