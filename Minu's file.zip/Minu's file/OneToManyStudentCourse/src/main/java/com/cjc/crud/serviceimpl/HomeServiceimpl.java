package com.cjc.crud.serviceimpl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.crud.model.Course;
import com.cjc.crud.model.Student;
import com.cjc.crud.repoistory.CourseRepository;
import com.cjc.crud.repoistory.StudentRepository;
import com.cjc.crud.service.HomeService;

@Service
public class HomeServiceimpl implements HomeService{
	
	
	
	@Autowired
	CourseRepository cr;
	@Autowired
	StudentRepository sr;

	@Override
	public Course insertcourse(Course c) {
		c.getSlist();
		return cr.save(c);
	}

	@Override
	public List<Course> getdata() {
		
		return cr.findAll();
	}

	@Override
	public Course updateCourse(int id, Course c) {
		Course cl=cr.getById(id);
		cl.setCid(id);
		cl.setCname(c.getCname());
		cl.setDuration(c.getDuration());
		cl.setFees(c.getFees());
		cl.setSlist(c.getSlist());
		return cr.save(cl);
	}

	@Override
	public List<Student> insertStu(List<Student> sl) {
		List<Student> slist=sr.saveAll(sl);
		return null;
	}

	@Override
	public List<Student> getStu() {
		
		return sr.findAll();
	}

	@Override
	public void deleteStu(int id) {
		sr.deleteById(id);
		
	}

	

	@Override
	public Student getbyname(String nm) {
		
		return sr.findByName(nm);
	}
	
	@Override
	public Course getSingleStu(Student s) {
		
		
		Course cl=cr.findBySlist(s);
		return cl;
	}

	

	

	

	

	


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	


	

	

}
