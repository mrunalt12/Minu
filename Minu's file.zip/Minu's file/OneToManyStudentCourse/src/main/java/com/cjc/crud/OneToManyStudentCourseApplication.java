package com.cjc.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToManyStudentCourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneToManyStudentCourseApplication.class, args);
	}

}
