package com.cjc.crud.repoistory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.crud.model.Course;
import com.cjc.crud.model.Student;
@Repository
public interface CourseRepository extends JpaRepository<Course, Integer>{

	

	Course findBySlist(Student stu);

	

	

	

}
