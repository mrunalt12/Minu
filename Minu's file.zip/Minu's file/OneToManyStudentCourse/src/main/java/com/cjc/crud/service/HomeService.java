package com.cjc.crud.service;

import java.util.List;

import com.cjc.crud.model.Course;
import com.cjc.crud.model.Student;

public interface HomeService {

	Course insertcourse(Course c);

	List<Course> getdata();

	Course updateCourse(int id, Course c);

	List<Student> insertStu(List<Student> sl);

	List<Student> getStu();

	void deleteStu(int id);

	Course getSingleStu(Student s);

	Student getbyname(String nm);

	

	

	

	//List<Student> saveStudent(Student s);


	

	
	

}
